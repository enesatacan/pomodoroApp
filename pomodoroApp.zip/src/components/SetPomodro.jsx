import { useState } from "react";
import Card from "../UI/Card";
import Button from "../UI/Buttons";
import useTimer from "../Hooks/useTimer";
import sound from "../finishMusic.mp3";
import { IoIosTimer } from "react-icons/io";

function SetPomodro({ isFinish, setIsFinish }) {
  const [hasStarted, setHasStarted] = useState(false);
  const finishSound = new Audio(sound);

  const { timeLeft, startTimer, formatTime } = useTimer(0.1 * 60, () => {
    finishSound.play();
    setIsFinish(true);
  });

  const handleStart = () => {
    setHasStarted(true);
    startTimer();
  };

  return (
    <Card className={`p-5 text-white ${isFinish ? "card-mission-active" : ""}`}>
      <p className="text-2xl">
        <strong>2 & 3 - </strong>
        Set Pomodoro and Work With Focus
      </p>
      <div className="timer flex justify-center items-center gap-5 m-4">
        <span className="font-bold text-2xl">
          <IoIosTimer />
        </span>
        <span className="text-4xl">{formatTime(timeLeft)}</span>
      </div>
      {!isFinish && !hasStarted && (
        <Button onClick={handleStart} className={"nextBtn"}>
          Start
        </Button>
      )}
    </Card>
  );
}

export default SetPomodro;
