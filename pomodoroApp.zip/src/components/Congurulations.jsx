import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Card from "../UI/Card";
import Button from "../UI/Buttons";
import { TiStarFullOutline } from "react-icons/ti";

function Congurulations({ setCount }) {
  const navigate = useNavigate();

  const [stars] = useState(4);

  const resetPomodoro = () => {
    localStorage.removeItem("pomodoroCount");
    setCount(0);
    navigate("/");
  };

  return (
    <Card className={"card-mission-active"}>
      <h2 className="p-5 text-xl text-white">
        You Finished One Full Cycle with the Pomodoro Technique.
      </h2>
      <div className="flex justify-center items-center bg-white p-5">
        {Array(stars)
          .fill()
          .map((_, index) => (
            <TiStarFullOutline
              key={index}
              className="text-yellow-500 text-4xl "
            />
          ))}
      </div>
      <Button
        onClick={resetPomodoro}
        className="rounded-md bg-white reset-btn p-3 m-5"
      >
        Work Again with the Pomodoro Technique
      </Button>
    </Card>
  );
}

export default Congurulations;
