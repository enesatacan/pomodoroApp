import { useState } from "react";
import Card from "../UI/Card";
import Button from "../UI/Buttons";
import "./styles/Mission.css";
function Mission({ mission, setMission, inputMission, setInputMission }) {
  const [error, setError] = useState("");
  const handleNext = (e) => {
    e.preventDefault();
    if (inputMission.trim().length > 0) {
      console.log("Task Add Successful");
      console.log("Started");
      setMission(true);
      setError("");
    } else {
      setError("Please Enter your Mission!");
    }
  };
  const handleChange = (e) => {
    setInputMission(e.target.value);
    setError("");
  };

  return (
    <Card className={mission ? "card-mission-active" : ""}>
      <form className="flex justify-center items-center flex-col p-5">
        <label className="text-2xl text-white p-2 rounded-md">
          <strong>1 - </strong>

          {mission ? "Your Mission" : "Your Mission"}
        </label>
        {mission ? (
          <p className="text-xl text-white p-2 m-5">{inputMission}</p>
        ) : (
          <>
            <textarea
              onChange={handleChange}
              className="rounded-md m-5 p-2 textarea"
              type="text"
            />
            {error && (
              <p className="bg-red-500 text-white mb-5 p-2 rounded-md">
                {error}
              </p>
            )}{" "}
            <Button onClick={handleNext} className={"nextBtn"}>
              Next
            </Button>
          </>
        )}
      </form>
    </Card>
  );
}

export default Mission;
