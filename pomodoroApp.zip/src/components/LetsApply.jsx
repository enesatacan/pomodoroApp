import { useEffect, useState } from "react";
import Mission from "./Mission";
import SetPomodro from "./SetPomodro";
import ShortBreak from "./ShortBreak";
import PomodroCount from "./pomodroCount";
import Congurulations from "./Congurulations";

function LetsApply() {
  const [mission, setMission] = useState(false);
  const [inputMission, setInputMission] = useState("");
  const [isFinish, setIsFinish] = useState(false);
  const [count, setCount] = useState(() => {
    const savedCount = localStorage.getItem("pomodoroCount");

    return savedCount !== null && !isNaN(Number(savedCount))
      ? JSON.parse(savedCount)
      : 0;
  });

  useEffect(() => {
    if (count < 4) {
      localStorage.setItem("pomodoroCount", JSON.stringify(count));
    }
  }, [count]);

  return (
    <div className="text-center">
      <PomodroCount count={count} />
      {count === 4 ? (
        <>
          <Congurulations setCount={setCount} />
        </>
      ) : (
        <>
          <Mission
            mission={mission}
            setMission={setMission}
            inputMission={inputMission}
            setInputMission={setInputMission}
          />
          {mission && (
            <SetPomodro isFinish={isFinish} setIsFinish={setIsFinish} />
          )}
          {isFinish && (
            <ShortBreak
              setCount={setCount}
              count={count}
              setIsFinish={setIsFinish}
            />
          )}
        </>
      )}
    </div>
  );
}

export default LetsApply;
