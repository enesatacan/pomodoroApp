import Card from "../UI/Card";
import Button from "../UI/Buttons";
import useTimer from "../Hooks/useTimer";
import sound from "../finishMusic.mp3";
import { IoIosTimer } from "react-icons/io";
import { useEffect, useState } from "react";

function ShortBreak({ setCount, count }) {
  const finishSound = new Audio(sound);
  const timerDuration = count === 3 ? 0.1 * 60 : 5 * 60;

  const [firstPomodroFinish, setFirstPomodroFinish] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const { timeLeft, startTimer, formatTime } = useTimer(timerDuration, () => {
    console.log("Short break finished!");
    finishSound.play();
    setFirstPomodroFinish(true);
  });

  useEffect(() => {
    if (firstPomodroFinish) {
      setCount((prevCount) => prevCount + 1);
    }
  }, [firstPomodroFinish, setCount]);

  const handleReset = () => {
    window.location.reload();
  };

  const handleStart = () => {
    setHasStarted(true);
    startTimer();
  };

  return (
    <>
      <Card
        className={`p-5 text-white ${
          firstPomodroFinish ? "card-mission-active" : ""
        }`}
      >
        <p className="text-2xl">
          <strong>4 - </strong>
          {count === 3 ? "Break" : "Short Break"}
        </p>
        <div className="timer flex justify-center items-center gap-5 m-4">
          <span className="font-bold text-2xl">
            <IoIosTimer />
          </span>
          <span className="text-4xl">{formatTime(timeLeft)}</span>
        </div>
        {!firstPomodroFinish && !hasStarted && (
          <Button onClick={handleStart} className={"nextBtn"}>
            Start
          </Button>
        )}
        {firstPomodroFinish && (
          <Button onClick={handleReset} className={"nextBtn"}>
            {count + 1}. Start Pomodoro
          </Button>
        )}
      </Card>
    </>
  );
}

export default ShortBreak;
