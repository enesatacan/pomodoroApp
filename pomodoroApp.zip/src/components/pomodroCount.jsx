import { FaClipboardCheck } from "react-icons/fa6";

function pomodroCount({ count }) {
  return (
    <div className="flex justify-center items-center m-5">
      <span
        style={{ background: "#34495E" }}
        className="justify-center items-center flex gap-2 border-solid  rounded-full p-5 text-white"
      >
        <FaClipboardCheck className="text-2xl" />
        <span className="font-bold text-2xl cursor-default">{count}</span>
      </span>
    </div>
  );
}

export default pomodroCount;
