import stepsData from "../Data/stepsData";
import Buttons from "../UI/Buttons";
import { useNavigate } from "react-router-dom";
function PomodroSteps() {
  const navigate = useNavigate();
  const handleLets = () => {
    navigate("/letsApply");
    console.log("Has been selected");
  };
  return (
    <>
      <div className="text-white">
        <div className="flex flex-col justify-center gap-5 ">
          <h2 className="text-2xl m-2">Steps of Pomodoro Technique:</h2>

          <div>
            {stepsData.map((step, index) => (
              <div key={index} className="grid grid-cols-3 mb-5">
                <span className="col-span-1 flex justify-center items-center text-3xl">
                  {step.number}
                </span>
                <span className="col-span-2">
                  <strong> {step.title}</strong>
                  <p> {step.description}</p>
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="text-center m-3">
        <Buttons
          onClick={handleLets}
          className=" button bg-white p-3 rounded-lg font-light"
        >
          Let's Apply Pomodoro
        </Buttons>
      </div>
    </>
  );
}

export default PomodroSteps;
