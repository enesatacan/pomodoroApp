import LetsApply from "./components/LetsApply";
import Pomodoro from "./Pomodoro";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

function App() {
  return (
    <Router>
      <Routes>
        <Route path={"/"} element={<Pomodoro />} />
        <Route path={"/letsApply"} element={<LetsApply />} />
      </Routes>
    </Router>
  );
}

export default App;
