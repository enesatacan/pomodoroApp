import Card from "./UI/Card";
import Steps from "./components/PomodroSteps";

function Pomodoro() {
  return (
    <>
      <Card className={"p-8"}>
        <div className="grid grid-cols-2 gap-4 justify-center items-center">
          <div className="row-span-1 col-span-2 md:col-span-1 flex flex-col justify-center">
            <h2 className="text-5xl text-white font-bold mb-4">
              Pomodoro Technique
            </h2>
            <p className="text-white text-justify">
              The Pomodoro Technique is a time management method developed by
              Francesco Cirillo to increase productivity and minimize
              distraction. This technique divides tasks into short, focused work
              sessions with breaks in between.
            </p>
          </div>
          <div className="row-span-1 col-span-2 md:col-span-1 flex flex-col items-center">
            <img
              className="rounded-full w-[12rem] hidden md:block"
              src="https://images.penguinrandomhouse.com/author/2148540"
              alt="Francesco Cirillo"
            />
            <span className="text-white font-extrabold hidden md:block">
              Francesco Cirillo
            </span>
          </div>
        </div>
        <Steps />
      </Card>
    </>
  );
}

export default Pomodoro;
