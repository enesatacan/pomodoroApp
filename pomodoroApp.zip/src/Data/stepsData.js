import { RiNumber1 } from "react-icons/ri";
import { RiNumber2 } from "react-icons/ri";
import { RiNumber3 } from "react-icons/ri";
import { RiNumber4 } from "react-icons/ri";
import { RiNumber5 } from "react-icons/ri";

const stepsData = [
  {
    number: <RiNumber1 />,
    title: "Define Your Mission",
    description: "Choose the work or project you want to do.",
  },
  {
    number: <RiNumber2 />,
    title: "Set Pomodoro (25 minutes):",
    description:
      "Start a 25-minute timer. During this time, focus only on that task.",
  },
  {
    number: <RiNumber3 />,
    title: "Work with Focus",
    description:
      "Focus completely on the task, no distractions, until the timer runs out.",
  },
  {
    number: <RiNumber4 />,
    title: "Short Break (5 minutes):",
    description:
      "After a 25-minute training session, take a 5-minute break. During this time you can stand up, take a short walk or just relax.",
  },
  {
    number: <RiNumber5 />,
    title: "After 4 Pomodoros, Take a Long Break (30 minutes): ",
    description:
      "4 Once the Pomodoro session is complete, take a longer break, trying to give your mind a complete rest.",
  },
];
export default stepsData;
