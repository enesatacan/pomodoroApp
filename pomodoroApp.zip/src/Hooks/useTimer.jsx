import { useState, useEffect } from "react";

const useTimer = (initialTime, onFinish) => {
  const [timeLeft, setTimeLeft] = useState(initialTime);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    let interval = null;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prevTime) => prevTime - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      clearInterval(interval);
      if (onFinish) onFinish();
    }

    return () => clearInterval(interval);
  }, [isActive, timeLeft, onFinish]);

  const startTimer = () => {
    setIsActive(true);
  };

  const resetTimer = (newTime) => {
    setIsActive(false);
    setTimeLeft(newTime);
  };

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs < 10 ? "0" : ""}${secs}`;
  };

  return { timeLeft, isActive, startTimer, resetTimer, formatTime };
};

export default useTimer;
